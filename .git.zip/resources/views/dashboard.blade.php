<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>
    <link rel="stylesheet" href="{{ asset('css/dashboard.css') }}" />

    <div class="py-12 bg-gray-100">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 text-center">
                
                <!-- Card 1 -->
                <div class="bg-white rounded shadow overflow-hidden">
                    <div class="bg-indigo-600 text-white py-2 font-semibold">Registration</div>
                    <div class="p-6">
                        <p class="text-3xl font-bold">{{ $totalDonors ?? 0 }}</p>
                        <p class="text-gray-500 mt-2">TOTAL REGISTERED DONORS</p>
                    </div>
                </div>

                <!-- Card 2 -->
                <div class="bg-white rounded shadow overflow-hidden">
                    <div class="bg-indigo-600 text-white py-2 font-semibold">Registration</div>
                    <div class="p-6">
                        <p class="text-3xl font-bold">{{ $weeklyDonors ?? 0 }}</p>
                        <p class="text-gray-500 mt-2">WEEKLY REGISTRATION</p>
                    </div>
                </div>

                <!-- Card 3 -->
                <div class="bg-white rounded shadow overflow-hidden">
                    <div class="bg-indigo-600 text-white py-2 font-semibold">Registration</div>
                    <div class="p-6">
                        <p class="text-3xl font-bold">{{ $monthlyDonors ?? 0 }}</p>
                        <p class="text-gray-500 mt-2">MONTHLY REGISTRATION</p>
                    </div>
                </div>

                <!-- Card 4 -->
                <div class="bg-white rounded shadow overflow-hidden">
                    <div class="bg-indigo-600 text-white py-2 font-semibold">Availability</div>
                    <div class="p-6">
                        <p class="text-3xl font-bold">{{ $totalDonors ?? 0 }}</p>
                        <p class="text-gray-500 mt-2">TOTAL AVAILABILITY</p>
                    </div>
                </div>

            </div>
            
            <!-- NEW LIVES AND RENEWALS -->
            <div class="graph-card mt-6">
                <div class="graph-card-header">
                    <h3>Monthly Count of New Lives and Renewals</h3>
                    <a href="/2025/dashboard/lives_2025">
                        <i class="bx bx-fullscreen bx-burst-hover bx-sm"></i>
                    </a>
                </div>
                <div class="graph-card-footer">
                    <iframe
                        id="lives_2025_iframe"
                        src=""
                        frameborder="0"
                        class="auto-height"
                    ></iframe>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
