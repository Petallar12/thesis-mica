<x-app-layout>

<div class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
    <h2 class="text-2xl font-semibold text-gray-700 mb-6">Donors List</h2>

    <table class="min-w-full bg-white border border-gray-200">
        <thead>
            <tr>
                <th class="py-2 px-4 border-b">ID</th>
                <th class="py-2 px-4 border-b">First Name</th>
                <th class="py-2 px-4 border-b">Last Name</th>
                <th class="py-2 px-4 border-b">Age</th>
                <th class="py-2 px-4 border-b">Blood Type</th>
                <th class="py-2 px-4 border-b">Gender</th>
                <th class="py-2 px-4 border-b">Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach($donors as $donor)
            <tr class="text-center">
                <td class="py-2 px-4 border-b">{{ $donor->id }}</td>
                <td class="py-2 px-4 border-b">{{ $donor->first_name }}</td>
                <td class="py-2 px-4 border-b">{{ $donor->last_name }}</td>
                <td class="py-2 px-4 border-b">{{ $donor->age }}</td>
                <td class="py-2 px-4 border-b">{{ $donor->blood_type }}</td>
                <td class="py-2 px-4 border-b">{{ $donor->gender }}</td>
                <td class="py-2 px-4 border-b flex gap-2 justify-center">
                    <a href="{{ route('donors.show', $donor->id) }}" class="text-blue-600 hover:underline">Show</a>
                    <a href="{{ route('donors.edit', $donor->id) }}" class="text-yellow-600 hover:underline">Edit</a>
                    <form action="{{ route('donors.destroy', $donor->id) }}" method="POST" onsubmit="return confirm('Are you sure?')">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="text-red-600 hover:underline">Delete</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
</x-app-layout>

