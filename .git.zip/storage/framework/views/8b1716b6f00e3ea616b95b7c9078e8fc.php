<table class="table table-bordered">
    <tbody>
        <tr><th class="th_modal">ID</th><td class="td_modal"><?php echo e($donor->id); ?></td></tr>
        <tr><th class="th_modal">First Name</th><td class="td_modal"><?php echo e($donor->first_name); ?></td></tr>
        <tr><th class="th_modal">Middle Name</th><td class="td_modal"><?php echo e($donor->middle_name); ?></td></tr>
        <tr><th class="th_modal">Last Name</th><td class="td_modal"><?php echo e($donor->last_name); ?></td></tr>
        <tr><th class="th_modal">Government ID Number</th><td class="td_modal"><?php echo e($donor->goverment_id_number); ?></td></tr>
        <tr><th class="th_modal">Contact Information</th><td class="td_modal"><?php echo e($donor->contact_information); ?></td></tr>
        <tr><th class="th_modal">Blood Type</th><td class="td_modal"><?php echo e($donor->blood_type); ?></td></tr>
        <tr><th class="th_modal">Age</th><td class="td_modal"><?php echo e($donor->age); ?></td></tr>
        <tr><th class="th_modal">Organ Needed</th><td class="td_modal"><?php echo e($donor->organ_needed); ?></td></tr>
        <tr><th class="th_modal">Medical History</th><td class="td_modal"><?php echo e($donor->medical_history); ?></td></tr>
        <tr><th class="th_modal">Waiting Time</th><td class="td_modal"><?php echo e($donor->waiting_time); ?></td></tr>
        <tr><th class="th_modal">Donation Preferences</th><td class="td_modal"><?php echo e($donor->donation_preferences); ?></td></tr>
        <tr><th class="th_modal">Gender</th><td class="td_modal"><?php echo e($donor->gender); ?></td></tr>
        <tr><th class="th_modal">Encoded By<td class="td_modal"><?php echo e($donor->encoded_by); ?></td></tr>
            <tr><th class="th_modal">Encoded Date</th><td class="td_modal"><?php echo e($donor->encoded_date); ?></td></tr>
            <tr><th class="th_modal">Contact Number</th><td class="td_modal"><?php echo e($donor->contact_number); ?></td></tr>
            <tr><th class="th_modal">Donor Status</th><td class="td_modal"><?php echo e($donor->status); ?></td></tr>
    
        
    </tbody>
</table>
<?php /**PATH C:\Users\syste\thesis\resources\views/donors/partials/show.blade.php ENDPATH**/ ?>