

<div <?php echo e($attributes->merge(['class' => 'text-center'])); ?>>
    <h1 class="text-2xl font-bold text-gray-700">PhilNOS</h1>
    <h2 class="text-xl text-gray-600"></h2>
    <h1 class="text-2xl font-bold text-gray-700"></h1>
</div>
<?php /**PATH C:\Users\syste\thesis\resources\views/components/application-logo.blade.php ENDPATH**/ ?>