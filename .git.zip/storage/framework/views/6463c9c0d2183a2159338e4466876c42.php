<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>" />

    <div class="py-12 bg-gray-100">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 text-center">
                
                <!-- Card 1 -->
                <div class="bg-white rounded shadow overflow-hidden">
                    <div class="bg-indigo-600 text-white py-2 font-semibold">Registration</div>
                    <div class="p-6">
                        <p class="text-3xl font-bold">302</p>
                        <p class="text-gray-500 mt-2">TOTAL REGISTRATION</p>
                    </div>
                </div>

                <!-- Card 2 -->
                <div class="bg-white rounded shadow overflow-hidden">
                    <div class="bg-indigo-600 text-white py-2 font-semibold">Registration</div>
                    <div class="p-6">
                        <p class="text-3xl font-bold">1,103</p>
                        <p class="text-gray-500 mt-2">WEEKLY REGISTRATION</p>
                    </div>
                </div>

                <!-- Card 3 -->
                <div class="bg-white rounded shadow overflow-hidden">
                    <div class="bg-indigo-600 text-white py-2 font-semibold">Registration</div>
                    <div class="p-6">
                        <p class="text-3xl font-bold">180</p>
                        <p class="text-gray-500 mt-2">MONTHLY REGISTRATION</p>
                    </div>
                </div>

                <!-- Card 4 -->
                <div class="bg-white rounded shadow overflow-hidden">
                    <div class="bg-indigo-600 text-white py-2 font-semibold">Availability</div>
                    <div class="p-6">
                        <p class="text-3xl font-bold">1,348</p>
                        <p class="text-gray-500 mt-2">TOTAL AVAILABILITY</p>
                    </div>
                </div>

            </div>
            
            <!-- NEW LIVES AND RENEWALS -->
<div class="graph-card">
    <div class="graph-card-header">
        <h3>Monthly Count of New Lives and Renewals</h3>
        <a href="/2025/dashboard/lives_2025">
            <i class="bx bx-fullscreen bx-burst-hover bx-sm"></i>
        </a>
    </div>
    <div class="graph-card-footer">
        <iframe
            id="lives_2025_iframe"
            src=""
            frameborder="0"
            class="auto-height"
        ></iframe>
    </div>
</div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\syste\thesis\resources\views\dashboard.blade.php ENDPATH**/ ?>