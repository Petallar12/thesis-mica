<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/donor-modal.css')); ?>" />
    
    <div class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div class="p-6 bg-white border-b border-gray-200">
                <h2 class="text-2xl font-bold mb-4">Edit Donor</h2>
                <div id="successMessage" class="success-message"></div>

                <form id="donorForm" method="POST" action="<?php echo e(route('donors.update', $donor->id)); ?>" class="mt-4">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="tabs mb-4">
                        <button type="button" class="tab active" data-tab="personal">Personal Information</button>
                        <button type="button" class="tab" data-tab="medical">Medical Information</button>
                        <button type="button" class="tab" data-tab="contact">Contact Information</button>
                    </div>

                    <div id="personal" class="tab-content active">
                        <div class="form-group grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700">First Name *</label>
                                <input type="text" name="first_name" value="<?php echo e($donor->first_name); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm" required />
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Middle Name</label>
                                <input type="text" name="middle_name" value="<?php echo e($donor->middle_name); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm" />
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Last Name *</label>
                                <input type="text" name="last_name" value="<?php echo e($donor->last_name); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm" required />
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Government ID Number *</label>
                                <input type="text" name="goverment_id_number" value="<?php echo e($donor->goverment_id_number); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm" required />
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Blood Type *</label>
                                <select name="blood_type" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm" required>
                                    <?php $__currentLoopData = ['O+', 'O-', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($type); ?>" <?php echo e($donor->blood_type === $type ? 'selected' : ''); ?>><?php echo e($type); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Age *</label>
                                <input type="number" name="age" value="<?php echo e($donor->age); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm" required min="0" />
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Gender *</label>
                                <select name="gender" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm" required>
                                    <option value="Male" <?php echo e($donor->gender === 'Male' ? 'selected' : ''); ?>>Male</option>
                                    <option value="Female" <?php echo e($donor->gender === 'Female' ? 'selected' : ''); ?>>Female</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Status *</label>
                                <select name="status" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm" required>
                                    <option value="Active" <?php echo e($donor->status === 'Active' ? 'selected' : ''); ?>>Active</option>
                                    <option value="Inactive" <?php echo e($donor->status === 'Inactive' ? 'selected' : ''); ?>>Inactive</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div id="medical" class="tab-content">
                        <div class="form-group grid grid-cols-2 gap-4">
                            <div class="col-span-2">
                                <label class="block text-sm font-medium text-gray-700">Medical History *</label>
                                <textarea name="medical_history" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm" required rows="3"><?php echo e($donor->medical_history); ?></textarea>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Waiting Time *</label>
                                <input type="text" name="waiting_time" value="<?php echo e($donor->waiting_time); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm" required />
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Organ Needed *</label>
                                <input type="text" name="organ_needed" value="<?php echo e($donor->organ_needed); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm" required />
                            </div>
                            <div class="col-span-2">
                                <label class="block text-sm font-medium text-gray-700">Donation Preferences *</label>
                                <input type="text" name="donation_preferences" value="<?php echo e($donor->donation_preferences); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm" required />
                            </div>
                        </div>
                    </div>

                    <div id="contact" class="tab-content">
                        <div class="form-group grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Email Address *</label>
                                <input type="email" name="contact_information" value="<?php echo e($donor->contact_information); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm" required />
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Contact Number *</label>
                                <input type="text" name="contact_number" value="<?php echo e($donor->contact_number); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm" required />
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Encoded By *</label>
                                <input type="text" name="encoded_by" value="<?php echo e($donor->encoded_by); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm" required />
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Encoded Date *</label>
                                <input type="date" name="encoded_date" value="<?php echo e($donor->encoded_date); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm" required />
                            </div>
                        </div>
                    </div>

                    <div class="mt-6 flex justify-end space-x-3">
                        <a href="<?php echo e(route('donors.index')); ?>" class="cancel-btn px-4 py-2 rounded-md">Cancel</a>
                        <button type="submit" class="submit-btn px-4 py-2 rounded-md">Update Donor</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const tabs = document.querySelectorAll('.tab');
            const tabContents = document.querySelectorAll('.tab-content');
            const form = document.getElementById('donorForm');
            const successMessage = document.getElementById('successMessage');

            // Tab controls
            tabs.forEach(tab => {
                tab.addEventListener('click', () => {
                    tabs.forEach(t => t.classList.remove('active'));
                    tabContents.forEach(content => content.classList.remove('active'));
                    
                    tab.classList.add('active');
                    const tabId = tab.getAttribute('data-tab');
                    document.getElementById(tabId).classList.add('active');
                });
            });

            // Form submission
            form.addEventListener('submit', async (e) => {
                e.preventDefault();
                
                try {
                    const formData = new FormData(form);
                    const response = await fetch(form.action, {
                        method: 'POST',
                        body: formData,
                        headers: {
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                            'Accept': 'application/json'
                        }
                    });

                    const result = await response.json();
                    
                    if (result.success) {
                        successMessage.textContent = 'Donor updated successfully!';
                        successMessage.style.display = 'block';
                        
                        // Redirect to index page after 2 seconds
                        setTimeout(() => {
                            window.location.href = "<?php echo e(route('donors.index')); ?>";
                        }, 2000);
                    }
                } catch (error) {
                    console.error('Error:', error);
                    successMessage.textContent = 'An error occurred. Please try again.';
                    successMessage.style.display = 'block';
                    successMessage.style.backgroundColor = '#f44336';
                }
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?> <?php /**PATH C:\Users\syste\thesis\resources\views/donors/edit.blade.php ENDPATH**/ ?>