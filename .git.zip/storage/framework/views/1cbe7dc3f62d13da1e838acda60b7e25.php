<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/index.css')); ?>" />
    <link href="<?php echo e(asset('css/datatables.min.css')); ?>" rel="stylesheet" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <div class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <h2 class="header-title font-semibold text-gray-700 mb-6">Donors List</h2>



        <div class="container-index">
            <table id="donorsTable" class="table table-striped nowrap" style="width: 100%">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Age</th>
                        <th>
                            <select class="blood-type-filter" id="blood-type-filter">
                                <option value="">Blood type</option>
                                <option value="A+">A+</option>
                                <option value="A-">A-</option>
                                <option value="B+">B+</option>
                                <option value="B-">B-</option>
                                <option value="AB+">AB+</option>
                                <option value="AB-">AB-</option>
                                <option value="O+">O+</option>
                                <option value="O-">O-</option>
                            </select>
                        </th>   

                        <th>
                        <select class="gender-filter" id="gender-filter">
                            <option value="">Genders</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select></th>                      
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $donors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-center">
                        <td><?php echo e($donor->id); ?></td>
                        <td><?php echo e($donor->first_name); ?></td>
                        <td><?php echo e($donor->last_name); ?></td>
                        <td><?php echo e($donor->age); ?></td>
                        <td><?php echo e($donor->blood_type); ?></td>
                        <td><?php echo e($donor->gender); ?></td>
                        <td class="py-2 px-4 border-b flex gap-4 justify-center">
                            <a href="<?php echo e(route('donors.show', $donor->id)); ?>" class="actionBtn">
                                <i class="fa fa-eye"></i>
                            </a>
                            <a href="<?php echo e(route('donors.edit', $donor->id)); ?>" class="actionBtn">
                                <i class="fa-solid fa-square-pen"></i>
                            </a>
                            <form action="<?php echo e(route('donors.destroy', $donor->id)); ?>" method="POST" class="inline" onsubmit="return confirm('Are you sure?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="actionBtn">
                                    <i class="fa-solid fa-circle-minus"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.5/css/jquery.dataTables.min.css" />
    
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    
    <script src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>

    <script>
        $(document).ready(function () {
            var table = $('#donorsTable').DataTable({
                paging: true,
                searching: true,
                ordering: false,
                pageLength: 10,
                lengthMenu: [5, 10, 25, 50, 100],
                dom: '<"top"lf>rt<"bottom"ip><"clear">',
                language: {
                    search: "_INPUT_",
                    searchPlaceholder: "Search records..."
                }
            });

            // Apply blood type filter
            $('#blood-type-filter').on('change', function() {
                table.column(4).search(this.value).draw();
            });

            // Apply gender filter
            $('#gender-filter').on('change', function() {
                table.column(5).search(this.value).draw();
            });
        });
    </script>


    </style>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\syste\thesis\resources\views\donors\index.blade.php ENDPATH**/ ?>