<!-- Create Donor Modal -->
<div id="createDonorModal" class="modal">
    <div class="modal-content">
        <span class="close-btn" id="closeCreateDonorModal">&times;</span>
        <h2 class="modal-title">Register New Donor</h2>

        <div class="tabs">
            <button type="button" class="tab active" data-tab="personal">Personal Information</button>
            <button type="button" class="tab" data-tab="medical">Medical Information</button>
            <button type="button" class="tab" data-tab="contact">Contact Information</button>
        </div>

        <form id="createDonorForm" method="POST" action="<?php echo e(route('donor.store')); ?>">
            <?php echo csrf_field(); ?>
            
            <div id="personal" class="tab-content active">
                <div class="form-group">
                    <input type="text" name="first_name" placeholder="First Name *" required />
                    <input type="text" name="middle_name" placeholder="Middle Name *" required />
                    <input type="text" name="last_name" placeholder="Last Name *" required />
                    <input type="text" name="goverment_id_number" placeholder="Government-issued ID Number *" required />
                    <input type="number" name="age" placeholder="Age *" required min="0" />
                    <select name="gender" required>
                        <option value="">Select Gender *</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select>
                    <input type="text" name="donation_preferences" placeholder="Donation Preferences *" required />
                    <input type="text" name="status" placeholder="Status" />
                </div>
            </div>

            <div id="medical" class="tab-content">
                <div class="form-group">
                    <input type="text" name="medical_history" placeholder="Medical History *" required />
                    <select name="blood_type" required>
                        <option value="">Select Blood Type *</option>
                        <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                    </select>
                    <input type="text" name="organ_needed" placeholder="Organ Available/Needed *" required />
                    <input type="text" name="waiting_time" placeholder="Estimated Waiting Time *" required />
                </div>
            </div>

            <div id="contact" class="tab-content">
                <div class="form-group">
                    <input type="email" name="contact_information" placeholder="Email Address *" required />
                    <input type="text" name="contact_number" placeholder="Contact Number *" required />
                    <input type="hidden" name="encoded_by" value="<?php echo e(Auth::user()->name); ?>" />
                    <input type="hidden" name="encoded_date" value="<?php echo e(now()->format('Y-m-d')); ?>" />
                </div>
            </div>

            <div class="form-actions">
                <button type="button" class="cancel-btn" id="cancelCreateDonor">Cancel</button>
                <button type="submit" class="submit-btn">Submit</button>
            </div>
        </form>
    </div>
</div>

<style>
.form-group {
    display: flex;
    flex-wrap: wrap;
    gap: 1rem;
    margin: 1rem 0;
}

.form-group input,
.form-group select {
    flex: 1 1 45%;
    padding: 0.8rem;
    border: 1px solid #ccc;
    border-radius: 6px;
}

.form-actions {
    display: flex;
    justify-content: flex-end;
    gap: 1rem;
    margin-top: 1.5rem;
}

.submit-btn {
    background-color: #9c0f3f;
    color: white;
    padding: 0.7rem 1.5rem;
    border: none;
    border-radius: 6px;
    font-weight: bold;
    cursor: pointer;
}

.submit-btn:hover {
    background-color: #7a0c31;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('createDonorModal');
    const closeBtn = document.getElementById('closeCreateDonorModal');
    const cancelBtn = document.getElementById('cancelCreateDonor');
    const form = document.getElementById('createDonorForm');
    const tabs = document.querySelectorAll('#createDonorModal .tab');

    // Close modal handlers
    if (closeBtn) closeBtn.addEventListener('click', () => modal.style.display = 'none');
    if (cancelBtn) cancelBtn.addEventListener('click', () => modal.style.display = 'none');
    
    // Close on outside click
    window.addEventListener('click', (e) => {
        if (e.target === modal) modal.style.display = 'none';
    });

    // Tab switching
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            tabs.forEach(t => t.classList.remove('active'));
            document.querySelectorAll('#createDonorModal .tab-content').forEach(content => content.classList.remove('active'));
            
            tab.classList.add('active');
            const tabId = tab.getAttribute('data-tab');
            document.getElementById(tabId).classList.add('active');
        });
    });

    // Form submission
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        try {
            const formData = new FormData(form);
            const response = await fetch(form.action, {
                method: 'POST',
                body: formData,
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                    'Accept': 'application/json'
                }
            });

            const result = await response.json();
            
            if (result.success) {
                alert(result.message);
                modal.style.display = 'none';
                window.location.reload();
            }
        } catch (error) {
            console.error('Error:', error);
            alert('An error occurred. Please try again.');
        }
    });
});
</script> <?php /**PATH C:\Users\syste\thesis\resources\views/components/create-donor-modal.blade.php ENDPATH**/ ?>