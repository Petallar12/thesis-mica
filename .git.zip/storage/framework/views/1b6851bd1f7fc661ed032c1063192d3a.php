<!-- donor-modal.blade.php -->
<style>
  .modal {
      display: none;
      position: fixed;
      z-index: 999;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      overflow: auto;
      background-color: rgba(0,0,0,0.4);
  }

  .modal-content {
      background-color: #fff;
      margin: 5% auto;
      padding: 2rem;
      border-radius: 12px;
      width: 90%;
      max-width: 800px;
      position: relative;
  }

  .close-btn {
      position: absolute;
      top: 15px;
      right: 20px;
      font-size: 28px;
      font-weight: bold;
      cursor: pointer;
  }

  .form-group {
      display: flex;
      flex-wrap: wrap;
      gap: 1rem;
      margin: 1rem 0;
  }

  .form-group input,
  .form-group select {
      flex: 1 1 45%;
      padding: 0.8rem;
      border: 1px solid #ccc;
      border-radius: 6px;
  }

  .form-actions {
      display: flex;
      justify-content: flex-end;
      gap: 1rem;
      margin-top: 1.5rem;
  }

  .cancel-btn,
  .submit-btn {
      padding: 0.7rem 1.5rem;
      border: none;
      border-radius: 6px;
      font-weight: bold;
      cursor: pointer;
  }

  .cancel-btn {
      background-color: white;
      border: 1px solid #9c0f3f;
      color: #9c0f3f;
  }

  .submit-btn {
      background-color: #9c0f3f;
      color: white;
  }

  /* Tab styles */
  .tabs {
      display: flex;
      gap: 2px;
      background: #f0f0f0;
      padding: 10px 10px 0;
      border-radius: 8px 8px 0 0;
      margin: -2rem -2rem 2rem;
  }

  .tab {
      padding: 12px 20px;
      background: #fff;
      border: none;
      border-radius: 8px 8px 0 0;
      cursor: pointer;
      font-weight: 500;
      color: #666;
      transition: all 0.3s ease;
  }

  .tab:hover {
      background: #f8f8f8;
  }

  .tab.active {
      background: #9c0f3f;
      color: white;
  }

  .tab-content {
      display: none;
  }

  .tab-content.active {
      display: block;
      animation: fadeIn 0.3s ease;
  }

  @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
  }
</style>

<div id="donorModal" class="modal">
  <div class="modal-content">
      <span class="close-btn">&times;</span>
      <h2>Register to be a donor</h2>
      <br/><br/>

      <form method="POST" action="<?php echo e(route('donor.store')); ?>">
          <?php echo csrf_field(); ?>

          <div class="tabs">
              <button type="button" class="tab active" data-tab="personal">Personal Information</button>
              <button type="button" class="tab" data-tab="medical">Medical Information</button>
              <button type="button" class="tab" data-tab="contact">Contact Information</button>
          </div>

          <div id="personal" class="tab-content active">
              <div class="form-group">
                  <input type="text" name="first_name" placeholder="First Name *" required />
                  <input type="text" name="middle_name" placeholder="Middle Name *" required />
                  <input type="text" name="last_name" placeholder="Last Name *" required />
                  <input type="text" name="goverment_id_number" placeholder="Government-issued ID Number *" required />
                  <input type="text" name="blood_type" placeholder="Blood Type *" required />
                  <input type="number" name="age" placeholder="Age *" required min="0" />
                  <select name="gender" required>
                      <option value="">Select Gender *</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                  </select>
              </div>
          </div>

          <div id="medical" class="tab-content">
              <div class="form-group">
                  <input type="text" name="medical_history" placeholder="Medical History *" required />
                  <input type="text" name="waiting_time" placeholder="Estimated Waiting Time *" required />
                  <input type="text" name="donation_preferences" placeholder="Donation Preferences *" required />
                  <input type="text" name="organ_needed" placeholder="Organ Available/Needed *" required />
              </div>
          </div>

          <div id="contact" class="tab-content">
              <div class="form-group">
                  <input type="text" name="contact_information" placeholder="Mobile or Email *" required />
              </div>
          </div>

          <div class="form-actions">
              <button type="button" class="cancel-btn">Cancel</button>
              <button type="submit" class="submit-btn">Submit</button>
          </div>
      </form>
  </div>
</div>

<script>
  document.addEventListener('DOMContentLoaded', () => {
      const modal = document.getElementById('donorModal');
      const openBtn = document.querySelector('.register-btn');
      const closeBtn = document.querySelector('.close-btn');
      const cancelBtn = document.querySelector('.cancel-btn');
      const tabs = document.querySelectorAll('.tab');
      const tabContents = document.querySelectorAll('.tab-content');

      // Modal controls
      if (openBtn && modal && closeBtn && cancelBtn) {
          openBtn.addEventListener('click', () => modal.style.display = 'block');
          closeBtn.addEventListener('click', () => modal.style.display = 'none');
          cancelBtn.addEventListener('click', () => modal.style.display = 'none');

          window.onclick = (e) => {
              if (e.target === modal) modal.style.display = 'none';
          };
      }

      // Tab controls
      tabs.forEach(tab => {
          tab.addEventListener('click', () => {
              // Remove active class from all tabs and contents
              tabs.forEach(t => t.classList.remove('active'));
              tabContents.forEach(content => content.classList.remove('active'));

              // Add active class to clicked tab and corresponding content
              tab.classList.add('active');
              const tabId = tab.getAttribute('data-tab');
              document.getElementById(tabId).classList.add('active');
          });
      });
  });
</script>
  <?php /**PATH C:\Users\syste\thesis\resources\views\components\donor-modal.blade.php ENDPATH**/ ?>