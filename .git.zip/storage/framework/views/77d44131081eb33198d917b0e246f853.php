<!DOCTYPE html>
<html>
<head>
    <title>Thank You for Registering</title>
</head>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
    <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
        <h2 style="color: #9c0f3f;">Thank You for Registering as a Donor</h2>
        
        <p>Dear <?php echo e($donor->first_name); ?>,</p>
        
        <p>Thank you for registering with the Philippine Network for Organ Sharing. Your commitment to potentially helping others through organ donation is deeply appreciated.</p>
        
        <p>We have received your registration with the following details:</p>
        <ul>
            <li>Name: <?php echo e($donor->first_name); ?> <?php echo e($donor->middle_name); ?> <?php echo e($donor->last_name); ?></li>
            <li>Blood Type: <?php echo e($donor->blood_type); ?></li>
            <li>Organ: <?php echo e($donor->organ_needed); ?></li>
        </ul>
        
        <p>We will keep your information secure and confidential. If you have any questions or need to update your information, please don't hesitate to contact us.</p>
        
        <p>Best regards,<br>
        Philippine Network for Organ Sharing Team</p>
    </div>
</body>
</html> <?php /**PATH C:\Users\syste\thesis\resources\views/emails/donor-registration.blade.php ENDPATH**/ ?>