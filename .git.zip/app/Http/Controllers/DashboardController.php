<?php

namespace App\Http\Controllers;

use App\Models\Donor;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        try {
            // Get total donors
            $totalDonors = Donor::count();
            
            // Get weekly registrations (donors registered in the last 7 days)
            $weeklyDonors = Donor::where('created_at', '>=', Carbon::now()->subDays(7))->count();
            
            // Get monthly registrations (donors registered in the last 30 days)
            $monthlyDonors = Donor::where('created_at', '>=', Carbon::now()->subDays(30))->count();

            return view('dashboard', [
                'totalDonors' => $totalDonors,
                'weeklyDonors' => $weeklyDonors,
                'monthlyDonors' => $monthlyDonors
            ]);
        } catch (\Exception $e) {
            // Log the error
            \Log::error('Dashboard Error: ' . $e->getMessage());
            
            // Return view with default values if there's an error
            return view('dashboard', [
                'totalDonors' => 0,
                'weeklyDonors' => 0,
                'monthlyDonors' => 0
            ]);
        }
    }
} 